<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DonationScale extends Model
{
    //
}
