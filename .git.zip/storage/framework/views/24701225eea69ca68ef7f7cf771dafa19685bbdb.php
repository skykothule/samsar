
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/global/vendor/filament-tablesaw/tablesaw.css">
    <div class="page-header">
        <h1 class="page-title font_lato"><?php echo e('Samsar Shippings'); ?></h1>
        <div class="page-header-actions">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(URL::to('/dashboard')); ?>"><?php echo e(trans('app.home')); ?></a></li>
                <li class="active"><?php echo e('Order Details'); ?></li>
            </ol>
        </div>
    </div>
    <div class="page-content">
        <div class="panel">
            <div class="panel-body container-fluid">
                <!------------------------start insert, update, delete message ---------------->
                <div class="row">

                    
                        
                            
                                
                            
                            
                            
                        
                    
                    
                        
                            
                                
                            
                            
                            
                        
                    
                    
                        
                            
                                
                            
                            
                            
                        
                    
                </div>

                
                    
                        
                    
                    
                    
                    
                    
                        
                    
                    
                    
                    
                    
                    
                    

                    
                    
                    
                    

                    

                    
                    
                    
                    
                    
                    
                    
                    
                
                <div style="clear:both;"></div><br/>
                <div class="row row-lg">
                    <div class="col-sm-12" >
                        <!-- Example Basic Form -->
                        <p class="font-size-20 blue-grey-700">Order Details</p>
                        
                            
                                
                            
                        
                    <div class="row">
                            <div class="form-group col-sm-6">
                                <label class="control-label" for="inputBasicFirstName"><b>Ship Order Id   : </b> </label>
                                <span><?php echo e($orderdata[0]->order_id); ?></span>
                            </div>
                        <div class="form-group col-sm-6">
                            <label class="control-label" for="inputBasicFirstName"><b>Order date     : </b> </label>
                            <span><?php echo e(date('Y-m-d',strtotime($orderdata[0]->order_date))); ?></span>
                        </div>
                    </div> <div class="row">
                            <div class="form-group col-sm-6">
                                <label class="control-label" for="inputBasicFirstName"><b>Booking Status   : </b> </label>
                                <span>Pending</span>
                            </div>
                            <div class="form-group col-sm-6">
                                <label class="control-label" for="inputBasicFirstName"><b>Sail Date     : </b> </label>
                                <span><?php echo e(date('Y-m-d',strtotime($orderdata[0]->created_at))); ?></span>
                            </div>
                        </div> <div class="row">
                            <div class="form-group col-sm-6">
                                <label class="control-label" for="inputBasicFirstName"><b>Shipment Status    : </b> </label>
                                <span> Delivered - Media USA</span>
                            </div>
                            <div class="form-group col-sm-6">
                                <label class="control-label" for="inputBasicFirstName"><b>Organisation    : </b> </label>
                                <span><?php echo e($orderdata[0]->company_name); ?></span>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            <form method="post" action="<?php echo e(url('itemstatus')); ?>">
                <?php echo csrf_field(); ?>
                <div class="bs-example" data-example-id="single-button-dropdown" style="float:left; ">
                    <div class="btn-group">
                        <button data-placement="top" data-toggle="modal" rel="tooltip" title="item confirm"  data-original-title="item confirm"  class="btn btn-outline btn-success" data-target=".confirm" name="submitbutton"  type="submit" value="confirm"><span class="fa fa-check-square" aria-hidden="true"></span> Confirm</button>
                    </div>
                    <div class="btn-group">
                        <button data-placement="top" data-toggle="modal" rel="tooltip" title="item cancel"  data-original-title="item cancel"  class="btn btn-outline btn-warning" data-target=".cancel" name="submitbutton" type="submit" value="cancel"><span class="fa fa-ban" aria-hidden="true"></span> Cancel</button>
                    </div>
                    <div class="btn-group">
                        <button data-placement="top" data-toggle="modal" rel="tooltip" title="item split"  data-original-title="item cancel"  class="btn btn-outline btn-danger" data-target=".split" name="submitbutton"  type="submit" value="split"><span class="fa fa-columns" aria-hidden="true"></span> Split</button>
                    </div>
                </div>
                <div style="clear:both;"></div>

                <table class="tablesaw table-striped table-bordered tablesaw-columntoggle" data-tablesaw-mode="columntoggle" data-tablesaw-minimap="" id="table-3973">
                    <thead>
                    <tr>
                        <th>&nbsp;&nbsp;
                            <input type="checkbox" id="ckbCheckAll" />
                        </th>
                        <th data-tablesaw-priority="5" class="tablesaw-priority-5 tablesaw-cell-visible">Ship To Order ID</th>
                        <th data-tablesaw-priority="4">Ship To Name</th>
                        <th data-tablesaw-priority="3">Ship to Address</th>
                        <th data-tablesaw-priority="3">Total Weight</th>
                        <th data-tablesaw-priority="2">Tracking ID</th>
                        <th data-tablesaw-priority="2">Status</th>
                        
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $orderdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align: center">
                                <input type="checkbox" class="checkBoxClass" id="Checkbox<?php echo e($view->item_id); ?>" name="check_item[]" value="<?php echo e($view->item_id); ?>" />
                            </td>
                            <td class="tablesaw-priority-5 tablesaw-cell-visible"><?php echo e($view->item_id); ?></td>
                            <td class="tablesaw-priority-4"><?php echo e($view->ship_to_name); ?></td>
                            <td class="tablesaw-priority-3">
                                <?php echo e($view->ship_to_company); ?> <?php echo e($view->ship_to_add1); ?><br>
                                <?php if(is_null($view->ship_to_add2)): ?>

                                <?php else: ?>
                                    <?php echo e($view->ship_to_add2); ?>

                                <?php endif; ?>
                                <?php if(is_null($view->ship_to_add2)): ?>

                                 <?php else: ?>
                                    <?php echo e($view->ship_to_add3); ?>

                                <?php endif; ?>

                                <?php echo e($view->ship_to_city); ?> <?php echo e($view->ship_to_state); ?> <?php echo e($view->ship_to_pincode); ?><br>
                                <?php echo e($view->ship_to_country); ?>

                            </td>
                            <td class="tablesaw-priority-2"><?php echo e($view->total_weight); ?></td>
                            <td class="tablesaw-priority-1"><?php echo e($view->tracking_id); ?></td>
                            <td class="tablesaw-priority-1" style="color:#0b98de;font-weight: 700">INITIAL</td>
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            

                            
                            

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </form>
                <div style="clear:both;"></div><br/>

            
            <?php echo e($orderdata->appends(Request::only('search'))->links()); ?>

            <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div><br/>

    <div class="modal fade modal-3d-flip-vertical confirm" id="confirm" aria-hidden="true"
         aria-labelledby="exampleModalTitle" role="dialog" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title">Item Confirm</h4>
                </div>
                <div class="modal-body">
                    <p> Are you sure that you want to confirm this item's?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default margin-0" data-dismiss="modal"><?php echo e(trans('app.close')); ?></button>
                    <a class="btn btn-success btn-ok" >Confirm Item</a>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade modal-3d-flip-vertical cancel" id="cancel" aria-hidden="true"
         aria-labelledby="exampleModalTitle" role="dialog" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title">Item Cancel</h4>
                </div>
                <div class="modal-body">
                    <p> Are you sure that you want to cancel this item's?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default margin-0" data-dismiss="modal"><?php echo e(trans('app.close')); ?></button>
                    <a class="btn btn-warning btn-ok">Confirm Item</a>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade modal-3d-flip-vertical split" id="split" aria-hidden="true"
         aria-labelledby="exampleModalTitle" role="dialog" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title">Item Split</h4>
                </div>
                <div class="modal-body">
                    <p> Are you sure that you want to split this item's?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default margin-0" data-dismiss="modal"><?php echo e(trans('app.close')); ?></button>
                    <a class="btn btn-danger btn-ok">Confirm Item</a>
                </div>
            </div>
        </div>
    </div>
        <script type='text/javascript'>
            $('.confirm').on('show.bs.modal', function(e) {
                $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
            });
            $('.cancel').on('show.bs.modal', function(e) {
                $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
            });
            $('.split').on('show.bs.modal', function(e) {
                $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
            });
            $(document).ready(function() {
                $("body").tooltip({ selector: '[data-toggle=tooltip]' });
            });

            $(document).ready(function () {
                $("#ckbCheckAll").click(function () {
                    $(".checkBoxClass").prop('checked', $(this).prop('checked'));
                });

                $(".checkBoxClass").change(function(){
                    if (!$(this).prop("checked")){
                        $("#ckbCheckAll").prop("checked",false);
                    }
                });
            });
        </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>