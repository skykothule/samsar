<?php $__env->startSection('content'); ?>
<div class="frontend_content">
    <div class="slider-page"></div>
    <div class="service-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="service-taitle">
                        <h1>What client say!</h1>
                    </div>
                </div>
            </div>

            <div class="row">
                
                <div id="google-reviews">
                <div id="map-plug" style="position: relative; overflow: hidden;">
                <div style="height: 100%; width: 100%; position: absolute; top: 0px; left: 0px; background-color: rgb(229, 227, 223);">
                <div style="overflow: hidden;"></div>
                <div class="gm-style" style="position: absolute; z-index: 0; left: 0px; top: 0px; height: 100%; width: 100%; padding: 0px; border-width: 0px; margin: 0px;">
                <div tabindex="0" style="position: absolute; z-index: 0; left: 0px; top: 0px; height: 100%; width: 100%; padding: 0px; border-width: 0px; margin: 0px; cursor: url(&quot;https://maps.gstatic.com/mapfiles/openhand_8_8.cur&quot;), default; touch-action: pan-x pan-y;"><div style="z-index: 1; position: absolute; left: 50%; top: 50%; width: 100%;"><div style="position: absolute; left: 0px; top: 0px; z-index: 100; width: 100%;"><div style="position: absolute; left: 0px; top: 0px; z-index: 0;"></div></div><div style="position: absolute; left: 0px; top: 0px; z-index: 101; width: 100%;"></div><div style="position: absolute; left: 0px; top: 0px; z-index: 102; width: 100%;"></div><div style="position: absolute; left: 0px; top: 0px; z-index: 103; width: 100%;"></div>
                <div style="position: absolute; left: 0px; top: 0px; z-index: 0;"></div>
                </div>
                <div class="gm-style-pbc" style="z-index: 2; position: absolute; height: 100%; width: 100%; padding: 0px; border-width: 0px; margin: 0px; left: 0px; top: 0px; opacity: 0;"><p class="gm-style-pbt"></p>
                </div>
                <div style="z-index: 3; position: absolute; height: 100%; width: 100%; padding: 0px; border-width: 0px; margin: 0px; left: 0px; top: 0px; touch-action: pan-x pan-y;">
                <div style="z-index: 4; position: absolute; left: 50%; top: 50%; width: 100%;">
                <div style="position: absolute; left: 0px; top: 0px; z-index: 104; width: 100%;">
                </div>
                <div style="position: absolute; left: 0px; top: 0px; z-index: 105; width: 100%;">
                </div>
                <div style="position: absolute; left: 0px; top: 0px; z-index: 106; width: 100%;"></div>
                <div style="position: absolute; left: 0px; top: 0px; z-index: 107; width: 100%;"></div>
                </div></div>
                </div>
                <iframe aria-hidden="true" frameborder="0" src="about:blank" style="z-index: -1; position: absolute; width: 100%; height: 100%; top: 0px; left: 0px; border: none;"></iframe></div></div></div><div class="review-item"><div class="review-meta"><span class="review-author">Tom Martin</span><span class="review-sep">, </span><span class="review-date">Apr 4, 2018</span></div><div class="review-stars"><ul><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li></ul></div><p class="review-text">We have used Lisa and Michael many times as a B2B relationship and always find them to be quick, efficent, top quality and reasonably priced. Thanks for the great work guys.</p></div><div class="review-item"><div class="review-meta"><span class="review-author">Sam Harris</span><span class="review-sep">, </span><span class="review-date">Mar 1, 2018</span></div><div class="review-stars"><ul><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li></ul></div><p class="review-text">Used these guys for my parents place. Great service, had all the right equipment and were very professional with how they managed the job.</p></div><div class="review-item"><div class="review-meta"><span class="review-author">Michael Kelsey</span><span class="review-sep">, </span><span class="review-date">Jun 25, 2017</span></div><div class="review-stars"><ul><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li></ul></div><p class="review-text">Quality service all round. Very highly recommended both the gutter clearance and roof repair. All including Michael the owner thoroughly professional and no nonsense. Good value also. A+</p></div></div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>